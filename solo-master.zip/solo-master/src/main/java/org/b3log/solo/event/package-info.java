/**
 * Event processors.
 */
package org.b3log.solo.event;
