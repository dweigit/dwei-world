/**
 * Utilities.
 */
package org.b3log.solo.util;
